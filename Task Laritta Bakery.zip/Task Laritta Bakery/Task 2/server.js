const express = require('express');
const cors = require('cors');
const axios = require('axios');

const app = express();
const port = 3000;

// Enable CORS
app.use(cors());

const categories = [
    'politik',
    'ekonomi',
    'hukum',
    'olahraga',
    'metro',
    'humaniora'
];

app.get('/api/categories', (req, res) => {
    res.json({ categories });
});

app.get('/api/news', async (req, res) => {
  const query = req.query.q || '';
  const category = req.query.category || '';
  const page = req.query.page || 1;
  const sortBy = req.query.sortBy || '';  
  const newsPerPage = 5;

  try {
      
      if (!categories.includes(category)) {
          return res.status(400).json({ error: 'Kategori tidak valid' });
      }

      
      const apiUrl = `https://api-berita-indonesia.vercel.app/antara/${category}/`;
      const response = await axios.get(apiUrl);
      let newsData = response.data.data.posts;

      
      if (query) {
          newsData = newsData.filter(news =>
              news.title.toLowerCase().includes(query.toLowerCase()) ||
              news.description.toLowerCase().includes(query.toLowerCase())
          );
      }

      // Sorting berdasarkan kriteria
      if (sortBy === 'date') {
          newsData.sort((a, b) => new Date(b.pubDate) - new Date(a.pubDate));  // Sort by date
      } else if (sortBy === 'popularity') {
          newsData.sort((a, b) => b.popularity - a.popularity);  // Sort by popularity
      }

      // Menghitung totalItems dan totalPages
      const totalItems = newsData.length;
      const totalPages = Math.ceil(totalItems / newsPerPage);

      // Mengambil berita untuk halaman yang diminta
      const startIndex = (page - 1) * newsPerPage;
      const endIndex = startIndex + newsPerPage;
      const newsForPage = newsData.slice(startIndex, endIndex);

      res.json({
          items: newsForPage,
          totalItems: totalItems,
          totalPages: totalPages
      });
  } catch (error) {
      console.error('Terjadi kesalahan saat mengambil data', error);
      res.status(500).json({ error: 'Terjadi kesalahan pada server' });
  }
});

app.listen(port, () => {
  console.log(`Proxy server berjalan di http://localhost:${port}`);
});
