document.addEventListener('DOMContentLoaded', function () {
  const apiUrl = 'http://localhost:3000/api/news';
  let newsData = [];
  let currentPage = 1;
  const itemsPerPage = 5;

  async function fetchCategories() {
      try {
          const response = await fetch('http://localhost:3000/api/categories');
          const data = await response.json();
          const categorySelect = document.getElementById('category-select');
          data.categories.forEach(category => {
              const option = document.createElement('option');
              option.value = category;
              option.textContent = category.charAt(0).toUpperCase() + category.slice(1); // Mengubah huruf pertama menjadi kapital
              categorySelect.appendChild(option);
          });
      } catch (error) {
          console.error('Error fetching categories:', error);
      }
  }

  async function fetchNews(query = '', category = '', sortBy = '') {
      try {
          const response = await fetch(`${apiUrl}?q=${query}&category=${category}&sortBy=${sortBy}`);
          const data = await response.json();
          newsData = Array.isArray(data.items) ? data.items : [];
          currentPage = 1;
          displayNews();
      } catch (error) {
          console.error('Error fetching data:', error);
          alert('Failed to fetch news. Please try again later.');
      }
  }

  function displayPagination(totalPages) {
      const pagination = document.getElementById('pagination');
      pagination.innerHTML = '';
      const ul = document.createElement('ul');
      ul.classList.add('pagination', 'justify-content-center');

      const prevLi = document.createElement('li');
      prevLi.classList.add('page-item', currentPage === 1 ? 'disabled' : '');
      const prevLink = document.createElement('a');
      prevLink.classList.add('page-link');
      prevLink.href = '#';
      prevLink.textContent = 'Previous';
      prevLink.onclick = (e) => {
          e.preventDefault();
          if (currentPage > 1) {
              currentPage--;
              displayNews();
          }
      };
      prevLi.appendChild(prevLink);
      ul.appendChild(prevLi);

      for (let i = 1; i <= totalPages; i++) {
          const li = document.createElement('li');
          li.classList.add('page-item', i === currentPage ? 'active' : '');
          const link = document.createElement('a');
          link.classList.add('page-link');
          link.href = '#';
          link.textContent = i;
          link.onclick = (e) => {
              e.preventDefault();
              currentPage = i;
              displayNews();
          };
          li.appendChild(link);
          ul.appendChild(li);
      }

      const nextLi = document.createElement('li');
      nextLi.classList.add('page-item', currentPage === totalPages ? 'disabled' : '');
      const nextLink = document.createElement('a');
      nextLink.classList.add('page-link');
      nextLink.href = '#';
      nextLink.textContent = 'Next';
      nextLink.onclick = (e) => {
          e.preventDefault();
          if (currentPage < totalPages) {
              currentPage++;
              displayNews();
          }
      };
      nextLi.appendChild(nextLink);
      ul.appendChild(nextLi);

      pagination.appendChild(ul);
  }

  function displayNews() {
      const newsContainer = document.getElementById('news-container');
      newsContainer.innerHTML = '';

      if (newsData.length === 0) {
          newsContainer.innerHTML = '<p class="text-center">No news found.</p>';
          displayPagination(0);
          return;
      }

      const totalItems = newsData.length;
      const totalPages = Math.ceil(totalItems / itemsPerPage);
      const startIndex = (currentPage - 1) * itemsPerPage;
      const endIndex = startIndex + itemsPerPage;
      const currentPageItems = newsData.slice(startIndex, endIndex);

      currentPageItems.forEach(news => {
          const newsItem = document.createElement('div');
          newsItem.classList.add('card', 'mb-3');
          newsItem.style.maxWidth = '540px';

          newsItem.innerHTML = `
              <div class="row g-0">
                  <div class="col-md-4">
                      <img src="${news.thumbnail || 'https://via.placeholder.com/150'}" class="img-fluid rounded-start" alt="${news.title}">
                  </div>
                  <div class="col-md-8">
                      <div class="card-body">
                          <h5 class="card-title"><a href="${news.link}" target="_blank">${news.title}</a></h5>
                          <p class="card-text">${news.description || 'Deskripsi tidak tersedia.'}</p>
                      </div>
                  </div>
              </div>
          `;
          newsContainer.appendChild(newsItem);
      });

      displayPagination(totalPages);
  }

  const searchButton = document.getElementById('search-button');
  const inputs = ['search-query', 'category-select', 'sort-select'];

  inputs.forEach(inputId => {
      document.getElementById(inputId).addEventListener('input', () => {
          const hasInput = inputs.some(id => document.getElementById(id).value.trim() !== '');
          searchButton.disabled = !hasInput;
      });
  });

  searchButton.addEventListener('click', function () {
      const query = document.getElementById('search-query').value;
      const category = document.getElementById('category-select').value;
      const sortBy = document.getElementById('sort-select').value;
      fetchNews(query, category, sortBy);
  });

  fetchCategories();
  fetchNews();
});
